import logging
from typing import Dict, Optional

import networkx as nx
import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score
from torch import nn
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch_geometric.nn import GAE, GATv2Conv, GCNConv, SAGEConv, TransformerConv

from mfgsae._shared import (
    PreparedGraph,
    compute_metrics,
    compute_node_curvature_degree2,
    get_device,
    get_topology_degree,
    heuristic_redundancy,
    make_link_split,
    normalize_scores,
    set_seed,
    simplify_by_target_ndr,
)


def focal_bce_with_logits(
    logits: torch.Tensor,
    targets: torch.Tensor,
    alpha: float = 0.25,
    gamma: float = 2.0,
) -> torch.Tensor:
    bce = F.binary_cross_entropy_with_logits(logits, targets, reduction="none")
    probs = torch.sigmoid(logits)
    pt = torch.where(targets > 0.5, probs, 1.0 - probs)
    alpha_t = torch.where(targets > 0.5, torch.full_like(targets, alpha), torch.full_like(targets, 1.0 - alpha))
    loss = alpha_t * ((1.0 - pt).clamp(min=1e-6) ** gamma) * bce
    return loss.mean()


def random_edge_dropout(edge_index: torch.Tensor, edge_attr: torch.Tensor, drop_prob: float):
    if drop_prob <= 0.0 or edge_index.numel() == 0:
        return edge_index, edge_attr
    keep_mask = torch.rand(edge_index.shape[1], device=edge_index.device) > drop_prob
    if keep_mask.sum() < 2:
        return edge_index, edge_attr
    edge_index_new = edge_index[:, keep_mask]
    if edge_attr is None:
        return edge_index_new, edge_attr
    return edge_index_new, edge_attr[keep_mask]


def _build_branch_feature_masks(prepared: PreparedGraph) -> Dict[str, torch.Tensor]:
    feature_dim = prepared.pyg_data.num_features
    masks: Dict[str, torch.Tensor] = {}

    def make_mask(cols):
        mask = torch.zeros(feature_dim, dtype=torch.float)
        for col in cols:
            col = int(col)
            if 0 <= col < feature_dim:
                mask[col] = 1.0
        return mask

    groups = prepared.feature_groups
    topo_cols = list(groups.get("topology", []))
    sem_cols = list(groups.get("semantic", []))
    name_to_idx = {name: i for i, name in enumerate(prepared.feature_names)}

    def existing_indices(names):
        return [name_to_idx[name] for name in names if name in name_to_idx]

    sage_geo_cols = existing_indices(
        [
            "mean_edge_length",
            "curvature_score",
            "x",
            "y",
        ]
    )
    if not sage_geo_cols:
        sage_geo_cols = list(groups.get("geometry", []))

    trans_sem_cols = existing_indices(
        [
            "min_road_class",
            "is_bridge_tunnel_roundabout",
            "has_trunk",
            "has_skeleton",
            "has_local",
        ]
    )
    trans_sem_set = set(trans_sem_cols)
    gat_sem_cols = [col for col in sem_cols if int(col) not in trans_sem_set]
    if not gat_sem_cols:
        gat_sem_cols = sem_cols

    masks["gcn"] = make_mask(topo_cols)
    masks["sage"] = make_mask(sage_geo_cols)
    masks["gat"] = make_mask(gat_sem_cols)
    masks["trans"] = make_mask(trans_sem_cols if trans_sem_cols else sem_cols)
    return masks


def _topology_guard_signal(prepared: PreparedGraph) -> np.ndarray:
    vals = []
    for nid in prepared.node_list:
        degree = get_topology_degree(prepared.graph, nid)
        neighbors = list(prepared.graph.neighbors(nid))
        max_neighbor_degree = max((get_topology_degree(prepared.graph, nb) for nb in neighbors), default=0)
        critical_neighbor = any(prepared.critical_labels.get(nb, 0) == 1 for nb in neighbors)
        edge_classes = [int(edata.get("road_class", 2)) for _, _, edata in prepared.graph.edges(nid, data=True)]
        trunk_touch = any(cls == 0 for cls in edge_classes)
        val = 0.0
        if degree >= 3:
            val += 1.0
        elif degree == 2 and max_neighbor_degree >= 3:
            val += 0.7
        elif degree == 1 and max_neighbor_degree >= 3:
            val += 0.35
        if critical_neighbor:
            val += 0.8
        if trunk_touch:
            val += 0.5
        vals.append(val)
    return normalize_scores(np.asarray(vals, dtype=float))


def _strict_gcn_protect_signal(prepared: PreparedGraph, degree_signal: np.ndarray) -> np.ndarray:
    vals = []
    for i, nid in enumerate(prepared.node_list):
        degree = get_topology_degree(prepared.graph, nid)
        neighbors = list(prepared.graph.neighbors(nid))
        edge_classes = [int(edata.get("road_class", 2)) for _, _, edata in prepared.graph.edges(nid, data=True)]
        road_class = min(edge_classes) if edge_classes else 2
        intersection_neighbor = any(get_topology_degree(prepared.graph, nb) >= 3 for nb in neighbors)
        critical_neighbor = any(prepared.critical_labels.get(nb, 0) == 1 for nb in neighbors)
        val = 0.0
        if degree >= 3:
            val += 1.00
        elif degree == 2 and intersection_neighbor:
            val += 0.70
        elif degree == 1 and intersection_neighbor:
            val += 0.35
        if road_class == 0:
            val += 0.45
        elif road_class == 1 and degree >= 3:
            val += 0.18
        if critical_neighbor:
            val += 0.25
        val += 0.55 * float(degree_signal[i])
        vals.append(val)
    return normalize_scores(np.asarray(vals, dtype=float))


def _strict_gat_protect_signal(prepared: PreparedGraph, critical_signal: np.ndarray) -> np.ndarray:
    vals = []
    for i, nid in enumerate(prepared.node_list):
        neighbors = list(prepared.graph.neighbors(nid))
        edge_classes = [int(edata.get("road_class", 2)) for _, _, edata in prepared.graph.edges(nid, data=True)]
        road_class = min(edge_classes) if edge_classes else 2
        critical_neighbor_count = sum(1 for nb in neighbors if prepared.critical_labels.get(nb, 0) == 1)
        degree = get_topology_degree(prepared.graph, nid)
        val = 0.0
        if prepared.critical_labels.get(nid, 0) == 1:
            val += 1.20
        if critical_neighbor_count > 0:
            val += min(0.70, 0.28 * critical_neighbor_count)
        if road_class == 0 and degree >= 2:
            val += 0.32
        val += 0.85 * float(critical_signal[i])
        vals.append(val)
    return normalize_scores(np.asarray(vals, dtype=float))


def _branch_role_priors(prepared: PreparedGraph) -> Dict[str, np.ndarray]:
    geo_vals = []
    semantic_vals = []
    continuity_vals = []
    for nid in prepared.node_list:
        degree = get_topology_degree(prepared.graph, nid)
        curvature = compute_node_curvature_degree2(prepared.graph, nid)
        neighbors = list(prepared.graph.neighbors(nid))
        neighbor_degrees = [get_topology_degree(prepared.graph, nb) for nb in neighbors]
        max_neighbor_degree = max(neighbor_degrees) if neighbor_degrees else 0
        edge_classes = [int(edata.get("road_class", 2)) for _, _, edata in prepared.graph.edges(nid, data=True)]
        road_class = min(edge_classes) if edge_classes else 2
        class_variety = len(set(edge_classes))
        critical_neighbor_count = sum(1 for nb in neighbors if prepared.critical_labels.get(nb, 0) == 1)
        is_critical = prepared.critical_labels.get(nid, 0) == 1

        # Geometry/deletion prior: low-risk degree-1/2 local nodes.
        geo = 0.05
        if road_class == 2 and degree <= 2 and max_neighbor_degree <= 2 and critical_neighbor_count == 0:
            geo = 1.0 if curvature < 10.0 else 0.65
        elif road_class == 1 and degree == 2 and max_neighbor_degree <= 2 and critical_neighbor_count == 0:
            geo = 0.45 if curvature < 6.0 else 0.20
        geo_vals.append(geo)

        # Semantic protection prior: critical nodes / critical neighbors / high-class roads.
        sem = 0.08
        if is_critical:
            sem = 1.0
        elif critical_neighbor_count > 0:
            sem = 0.85
        elif road_class <= 1 and degree >= 2:
            sem = 0.50
        semantic_vals.append(sem)

        # Continuity prior: trunk/skeleton links and class-transition connectors.
        cont = 0.08
        if road_class == 0:
            cont = 1.0
        elif road_class == 1 and degree >= 2:
            cont = 0.72
        elif class_variety >= 2:
            cont = 0.56
        elif max_neighbor_degree >= 3:
            cont = 0.34
        continuity_vals.append(cont)

    return {
        "geometry": np.asarray(geo_vals, dtype=float),
        "semantic": np.asarray(semantic_vals, dtype=float),
        "continuity": np.asarray(continuity_vals, dtype=float),
    }


class GCNBranch(nn.Module):
    def __init__(self, in_channels: int, hidden_channels: int):
        super().__init__()
        self.conv1 = GCNConv(in_channels, hidden_channels)
        self.conv2 = GCNConv(hidden_channels, hidden_channels)
        self.skip = nn.Linear(in_channels, hidden_channels, bias=False)
        self.norm = nn.LayerNorm(hidden_channels)

    def forward(self, x, edge_index):
        residual = self.skip(x)
        x = F.elu(self.conv1(x, edge_index))
        x = self.norm(x)
        x = F.dropout(x, p=0.18, training=self.training)
        x = self.conv2(x, edge_index)
        return x + residual


class SAGEBranch(nn.Module):
    def __init__(self, in_channels: int, hidden_channels: int):
        super().__init__()
        self.conv1 = SAGEConv(in_channels, hidden_channels)
        self.conv2 = SAGEConv(hidden_channels, hidden_channels)
        self.skip = nn.Linear(in_channels, hidden_channels, bias=False)
        self.norm = nn.LayerNorm(hidden_channels)

    def forward(self, x, edge_index):
        residual = self.skip(x)
        x = F.elu(self.conv1(x, edge_index))
        x = self.norm(x)
        x = F.dropout(x, p=0.25, training=self.training)
        x = self.conv2(x, edge_index)
        return x + residual


class GATBranch(nn.Module):
    def __init__(self, in_channels: int, hidden_channels: int, heads: int):
        super().__init__()
        self.conv1 = GATv2Conv(in_channels, hidden_channels, heads=heads, concat=True, dropout=0.15)
        self.conv2 = GATv2Conv(hidden_channels * heads, hidden_channels, heads=heads, concat=True, dropout=0.15)
        self.skip = nn.Linear(in_channels, hidden_channels * heads, bias=False)
        self.norm = nn.LayerNorm(hidden_channels * heads)

    def forward(self, x, edge_index):
        residual = self.skip(x)
        x = F.elu(self.conv1(x, edge_index))
        x = self.norm(x)
        x = F.dropout(x, p=0.18, training=self.training)
        x = self.conv2(x, edge_index)
        return x + residual


class TransformerBranch(nn.Module):
    def __init__(self, in_channels: int, hidden_channels: int, edge_dim: int, heads: int):
        super().__init__()
        self.conv1 = TransformerConv(
            in_channels,
            hidden_channels,
            heads=heads,
            concat=True,
            edge_dim=edge_dim,
            dropout=0.15,
        )
        self.conv2 = TransformerConv(
            hidden_channels * heads,
            hidden_channels,
            heads=heads,
            concat=True,
            edge_dim=edge_dim,
            dropout=0.15,
        )

    def forward(self, x, edge_index, edge_attr):
        x = F.elu(self.conv1(x, edge_index, edge_attr))
        x = F.dropout(x, p=0.15, training=self.training)
        x = self.conv2(x, edge_index, edge_attr)
        return x


class EdgeAwareDecoder(nn.Module):
    def __init__(self, hidden_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(hidden_dim * 4, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ELU(),
            nn.Dropout(0.15),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ELU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim // 2, 1),
        )

    def forward(self, z, edge_index, edge_attr=None, sigmoid=True):
        src = z[edge_index[0]]
        dst = z[edge_index[1]]
        feat = torch.cat([src, dst, src * dst, torch.abs(src - dst)], dim=1)
        logits = self.net(feat).squeeze(-1)
        return torch.sigmoid(logits) if sigmoid else logits


class FourBranchFusionEncoder(nn.Module):
    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        edge_dim: int,
        heads: int = 4,
        active_branches=None,
        fusion_mode: str = "adaptive",
        encoder_mode: str = "multi_branch",
        gate_floor: float = 0.06,
        feature_masks: Optional[Dict[str, torch.Tensor]] = None,
    ):
        super().__init__()
        self.hidden_channels = hidden_channels
        self.heads = heads
        # Avoid silently falling back to the full model when an empty ablation
        # branch set is passed in by mistake.
        self.active_branches = set(
            {"gcn", "sage", "gat", "trans"}
            if active_branches is None
            else active_branches
        )
        if not self.active_branches:
            raise ValueError("active_branches cannot be empty")
        unknown = self.active_branches.difference({"gcn", "sage", "gat", "trans"})
        if unknown:
            raise ValueError(f"Unknown branches requested: {sorted(unknown)}")
        self.branch_order = ["gcn", "sage", "gat", "trans"]
        self.fusion_mode = fusion_mode
        self.encoder_mode = encoder_mode
        self.gate_floor = float(gate_floor)
        self.feature_masks = feature_masks or {}
        fusion_dim = hidden_channels * heads
        self.gcn = GCNBranch(in_channels, fusion_dim)
        self.sage = SAGEBranch(in_channels, fusion_dim)
        self.gat = GATBranch(in_channels, hidden_channels, heads)
        self.trans = TransformerBranch(in_channels, hidden_channels, edge_dim, heads)
        self.shared_encoder = GCNBranch(in_channels, fusion_dim)
        self.branch_norms = nn.ModuleDict(
            {
                "gcn": nn.LayerNorm(fusion_dim),
                "sage": nn.LayerNorm(fusion_dim),
                "gat": nn.LayerNorm(fusion_dim),
                "trans": nn.LayerNorm(fusion_dim),
            }
        )
        self.gate_net = nn.Sequential(
            nn.Linear(fusion_dim * 4, fusion_dim * 2),
            nn.ReLU(),
            nn.Dropout(0.15),
            nn.Linear(fusion_dim * 2, 4),
        )
        self.global_gate_logits = nn.Parameter(torch.zeros(4))

    def _active_mask(self, device):
        return torch.tensor(
            [1.0 if name in self.active_branches else 0.0 for name in self.branch_order],
            device=device,
        )

    def _normalize_gates(self, logits: torch.Tensor, active_mask: torch.Tensor) -> torch.Tensor:
        masked_logits = logits.masked_fill(active_mask.unsqueeze(0) == 0, -1e9)
        gates = torch.softmax(masked_logits / 1.2, dim=1)
        if self.gate_floor > 0.0:
            active_count = active_mask.sum().clamp(min=1.0)
            floor_each = self.gate_floor / active_count
            gates = active_mask.unsqueeze(0) * (floor_each + (1.0 - self.gate_floor) * gates)
            gates = gates / gates.sum(dim=1, keepdim=True).clamp(min=1e-8)
        return gates

    def _branch_input(self, x: torch.Tensor, branch_name: str) -> torch.Tensor:
        mask = self.feature_masks.get(branch_name)
        if mask is None:
            return x
        return x * mask.to(x.device)

    def forward_with_branches(self, x, edge_index, edge_attr):
        if self.encoder_mode == "unified":
            shared = self.branch_norms["sage"](self.shared_encoder(x, edge_index))
            zero = torch.zeros((x.shape[0], self.hidden_channels * self.heads), device=x.device)
            gates = torch.zeros((x.shape[0], 4), device=x.device)
            gates[:, 1] = 1.0
            return shared, {"gcn": zero, "sage": shared, "gat": zero, "trans": zero}, gates
        x1 = self.gcn(self._branch_input(x, "gcn"), edge_index) if "gcn" in self.active_branches else torch.zeros((x.shape[0], self.hidden_channels * self.heads), device=x.device)
        x2 = self.sage(self._branch_input(x, "sage"), edge_index) if "sage" in self.active_branches else torch.zeros((x.shape[0], self.hidden_channels * self.heads), device=x.device)
        x3 = self.gat(self._branch_input(x, "gat"), edge_index) if "gat" in self.active_branches else torch.zeros((x.shape[0], self.hidden_channels * self.heads), device=x.device)
        x4 = self.trans(self._branch_input(x, "trans"), edge_index, edge_attr) if "trans" in self.active_branches else torch.zeros((x.shape[0], self.hidden_channels * self.heads), device=x.device)
        x1 = self.branch_norms["gcn"](x1) if "gcn" in self.active_branches else x1
        x2 = self.branch_norms["sage"](x2) if "sage" in self.active_branches else x2
        x3 = self.branch_norms["gat"](x3) if "gat" in self.active_branches else x3
        x4 = self.branch_norms["trans"](x4) if "trans" in self.active_branches else x4
        concat = torch.cat([x1, x2, x3, x4], dim=1)
        active_mask = self._active_mask(x.device)
        if self.fusion_mode == "equal":
            gates = active_mask.unsqueeze(0).repeat(x.shape[0], 1)
            gates = gates / gates.sum(dim=1, keepdim=True).clamp(min=1e-8)
        elif self.fusion_mode == "global":
            logits = self.global_gate_logits.unsqueeze(0).repeat(x.shape[0], 1)
            gates = self._normalize_gates(logits, active_mask)
        else:
            logits = self.gate_net(concat)
            gates = self._normalize_gates(logits, active_mask)
        fused = (
            gates[:, 0:1] * x1
            + gates[:, 1:2] * x2
            + gates[:, 2:3] * x3
            + gates[:, 3:4] * x4
        )
        return fused, {"gcn": x1, "sage": x2, "gat": x3, "trans": x4}, gates

    def forward(self, x, edge_index, edge_attr):
        fused, _, _ = self.forward_with_branches(x, edge_index, edge_attr)
        return fused


class FourBranchRoadModel:
    def __init__(
        self,
        in_channels: int,
        edge_dim: int,
        active_branches=None,
        fusion_mode: str = "adaptive",
        encoder_mode: str = "multi_branch",
        feature_masks: Optional[Dict[str, torch.Tensor]] = None,
    ):
        self.device = get_device()
        encoder = FourBranchFusionEncoder(
            in_channels,
            hidden_channels=32,
            edge_dim=edge_dim,
            heads=4,
            active_branches=active_branches,
            fusion_mode=fusion_mode,
            encoder_mode=encoder_mode,
            feature_masks=feature_masks,
        )
        decoder = EdgeAwareDecoder(hidden_dim=128)
        self.model = GAE(encoder=encoder, decoder=decoder).to(self.device)
        self.encoder_mode = encoder_mode
        self.active_branches = set(
            {"gcn", "sage", "gat", "trans"}
            if active_branches is None
            else active_branches
        )
        self.branch_order = ["gcn", "sage", "gat", "trans"]
        branch_dim = 128
        self.aux_heads = nn.ModuleDict(
            {
                "gcn_degree": nn.Sequential(nn.Linear(branch_dim, 64), nn.ReLU(), nn.Linear(64, 1)),
                "sage_redundant": nn.Sequential(nn.Linear(branch_dim, 64), nn.ReLU(), nn.Linear(64, 1)),
                "gat_critical": nn.Sequential(nn.Linear(branch_dim, 64), nn.ReLU(), nn.Linear(64, 1)),
                "trans_roadclass": nn.Sequential(nn.Linear(branch_dim, 64), nn.ReLU(), nn.Linear(64, 3)),
                "trans_length": nn.Sequential(nn.Linear(branch_dim, 64), nn.ReLU(), nn.Linear(64, 1)),
            }
        ).to(self.device)
        self.fused_heads = nn.ModuleDict(
            {
                "degree": nn.Sequential(nn.Linear(branch_dim, 64), nn.ReLU(), nn.Linear(64, 1)),
                "redundant": nn.Sequential(nn.Linear(branch_dim, 64), nn.ReLU(), nn.Linear(64, 1)),
                "critical": nn.Sequential(nn.Linear(branch_dim, 64), nn.ReLU(), nn.Linear(64, 1)),
                "roadclass": nn.Sequential(nn.Linear(branch_dim, 64), nn.ReLU(), nn.Linear(64, 3)),
                "length": nn.Sequential(nn.Linear(branch_dim, 64), nn.ReLU(), nn.Linear(64, 1)),
            }
        ).to(self.device)

    def train(self, train_data, val_data, epochs: int = 70, lr: float = 0.0025, wd: float = 5e-4, patience: int = 10):
        train_data = train_data.to(self.device)
        val_data = val_data.to(self.device)
        params = list(self.model.parameters()) + list(self.aux_heads.parameters()) + list(self.fused_heads.parameters())
        optimizer = torch.optim.AdamW(params, lr=lr, weight_decay=wd)
        scheduler = ReduceLROnPlateau(optimizer, mode="max", factor=0.6, patience=6)
        best_auc = 0.0
        best_state = None
        wait = 0
        for epoch in range(1, epochs + 1):
            self.model.train()
            self.aux_heads.train()
            self.fused_heads.train()
            optimizer.zero_grad()
            train_edge_index, train_edge_attr = random_edge_dropout(train_data.edge_index, train_data.edge_attr, drop_prob=0.06)
            z, branches, gates = self.model.encoder.forward_with_branches(
                train_data.x,
                train_edge_index,
                train_edge_attr,
            )
            pos_logits = self.model.decoder(z, train_data.pos_edge_label_index, sigmoid=False)
            neg_logits = self.model.decoder(z, train_data.neg_edge_label_index, sigmoid=False)
            logits = torch.cat([pos_logits, neg_logits], dim=0)
            labels = torch.cat([torch.ones_like(pos_logits), torch.zeros_like(neg_logits)], dim=0)
            bce = F.binary_cross_entropy_with_logits(logits, labels)
            src, dst = train_edge_index[0], train_edge_index[1]
            smooth = ((z[src] - z[dst]) ** 2).mean()
            gcn_degree_pred = self.aux_heads["gcn_degree"](branches["gcn"]).squeeze(-1)
            sage_redundant_pred = self.aux_heads["sage_redundant"](branches["sage"]).squeeze(-1)
            gat_critical_pred = self.aux_heads["gat_critical"](branches["gat"]).squeeze(-1)
            trans_roadclass_pred = self.aux_heads["trans_roadclass"](branches["trans"])
            trans_length_pred = self.aux_heads["trans_length"](branches["trans"]).squeeze(-1)

            degree_loss = F.mse_loss(torch.sigmoid(gcn_degree_pred), train_data.y_degree)
            redundant_loss = focal_bce_with_logits(sage_redundant_pred, train_data.y_redundant, alpha=0.35, gamma=2.0)
            critical_loss = focal_bce_with_logits(gat_critical_pred, train_data.y_critical, alpha=0.40, gamma=2.0)
            roadclass_loss = F.cross_entropy(trans_roadclass_pred, train_data.y_roadclass)
            length_loss = F.mse_loss(torch.sigmoid(trans_length_pred), train_data.y_length)
            fused_degree_loss = F.mse_loss(
                torch.sigmoid(self.fused_heads["degree"](z).squeeze(-1)),
                train_data.y_degree,
            )
            fused_redundant_loss = focal_bce_with_logits(
                self.fused_heads["redundant"](z).squeeze(-1),
                train_data.y_redundant,
                alpha=0.35,
                gamma=2.0,
            )
            fused_critical_loss = focal_bce_with_logits(
                self.fused_heads["critical"](z).squeeze(-1),
                train_data.y_critical,
                alpha=0.40,
                gamma=2.0,
            )
            fused_roadclass_loss = F.cross_entropy(
                self.fused_heads["roadclass"](z),
                train_data.y_roadclass,
            )
            fused_length_loss = F.mse_loss(
                torch.sigmoid(self.fused_heads["length"](z).squeeze(-1)),
                train_data.y_length,
            )
            fused_task_loss = (
                0.08 * fused_degree_loss
                + 0.16 * fused_redundant_loss
                + 0.12 * fused_critical_loss
                + 0.08 * fused_roadclass_loss
                + 0.06 * fused_length_loss
            )

            aux_loss = 0.0
            if self.encoder_mode == "multi_branch":
                if "gcn" in self.active_branches:
                    aux_loss = aux_loss + 0.10 * degree_loss
                if "sage" in self.active_branches:
                    aux_loss = aux_loss + 0.30 * redundant_loss
                if "gat" in self.active_branches:
                    aux_loss = aux_loss + 0.24 * critical_loss
                if "trans" in self.active_branches:
                    aux_loss = aux_loss + 0.14 * roadclass_loss + 0.10 * length_loss

            branch_list = [branches[name] for name in self.branch_order if name in self.active_branches]
            diversity_loss = 0.0
            pair_count = 0
            gate_entropy = torch.tensor(0.0, device=self.device)
            gate_balance = torch.tensor(0.0, device=self.device)
            if self.encoder_mode == "multi_branch":
                for i in range(len(branch_list)):
                    for j in range(i + 1, len(branch_list)):
                        bi = F.normalize(branch_list[i], dim=1)
                        bj = F.normalize(branch_list[j], dim=1)
                        diversity_loss = diversity_loss + torch.mean(torch.abs(torch.sum(bi * bj, dim=1)))
                        pair_count += 1
                diversity_loss = diversity_loss / max(pair_count, 1)

                gate_entropy = -(gates * torch.log(gates.clamp_min(1e-8))).sum(dim=1).mean()
                active_mask = self.model.encoder._active_mask(gates.device)
                target_gate = active_mask / active_mask.sum().clamp(min=1.0)
                gate_balance = torch.sum((gates.mean(dim=0) - target_gate) ** 2)
            loss = (
                bce
                + 0.02 * smooth
                + aux_loss
                + fused_task_loss
                + 0.06 * diversity_loss
                + 0.03 * gate_balance
                - 0.003 * gate_entropy
            )
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=2.0)
            optimizer.step()

            self.model.eval()
            self.aux_heads.eval()
            self.fused_heads.eval()
            with torch.no_grad():
                z_val = self.model.encode(val_data.x, val_data.edge_index, val_data.edge_attr)
                pos_pred = self.model.decoder(z_val, val_data.pos_edge_label_index, sigmoid=True)
                neg_pred = self.model.decoder(z_val, val_data.neg_edge_label_index, sigmoid=True)
                y_pred = torch.cat([pos_pred, neg_pred]).detach().cpu().numpy()
                y_true = torch.cat([torch.ones_like(pos_pred), torch.zeros_like(neg_pred)]).detach().cpu().numpy()
                val_auc = float(roc_auc_score(y_true, y_pred))
            if epoch % 10 == 0 or epoch == 1:
                logging.info("OURS Epoch %03d | loss %.4f | val_auc %.4f", epoch, float(loss.item()), val_auc)
            if val_auc > best_auc + 1e-4:
                best_auc = val_auc
                best_state = {
                    "model": {k: v.detach().cpu().clone() for k, v in self.model.state_dict().items()},
                    "aux": {k: v.detach().cpu().clone() for k, v in self.aux_heads.state_dict().items()},
                    "fused": {k: v.detach().cpu().clone() for k, v in self.fused_heads.state_dict().items()},
                }
                wait = 0
            else:
                wait += 1
                if wait >= patience:
                    break
            scheduler.step(val_auc)
        if best_state is not None:
            self.model.load_state_dict(best_state["model"])
            self.aux_heads.load_state_dict(best_state["aux"])
            self.fused_heads.load_state_dict(best_state["fused"])

    def node_scores(self, prepared: PreparedGraph) -> np.ndarray:
        data = prepared.pyg_data.to(self.device)
        self.model.eval()
        self.aux_heads.eval()
        with torch.no_grad():
            z, branches, _ = self.model.encoder.forward_with_branches(data.x, data.edge_index, data.edge_attr)
            edge_probs = self.model.decoder(z, data.edge_index, sigmoid=True).detach().cpu().numpy()
            z_np = z.detach().cpu().numpy()
            if self.encoder_mode == "unified":
                gcn_degree_prob = torch.sigmoid(self.fused_heads["degree"](z).squeeze(-1)).detach().cpu().numpy()
                sage_redundant_prob = torch.sigmoid(self.fused_heads["redundant"](z).squeeze(-1)).detach().cpu().numpy()
                gat_critical_prob = torch.sigmoid(self.fused_heads["critical"](z).squeeze(-1)).detach().cpu().numpy()
                trans_roadclass_prob = torch.softmax(self.fused_heads["roadclass"](z), dim=1).detach().cpu().numpy()
                trans_length_prob = torch.sigmoid(self.fused_heads["length"](z).squeeze(-1)).detach().cpu().numpy()
            else:
                gcn_degree_prob = torch.sigmoid(self.aux_heads["gcn_degree"](branches["gcn"]).squeeze(-1)).detach().cpu().numpy()
                sage_redundant_prob = torch.sigmoid(self.aux_heads["sage_redundant"](branches["sage"]).squeeze(-1)).detach().cpu().numpy()
                gat_critical_prob = torch.sigmoid(self.aux_heads["gat_critical"](branches["gat"]).squeeze(-1)).detach().cpu().numpy()
                trans_roadclass_prob = torch.softmax(self.aux_heads["trans_roadclass"](branches["trans"]), dim=1).detach().cpu().numpy()
                trans_length_prob = torch.sigmoid(self.aux_heads["trans_length"](branches["trans"]).squeeze(-1)).detach().cpu().numpy()
        node_probs = {nid: [] for nid in prepared.node_list}
        for idx, (u, v) in enumerate(data.edge_index.t().detach().cpu().numpy()):
            prob = float(edge_probs[idx])
            node_probs[prepared.node_list[int(u)]].append(prob)
            node_probs[prepared.node_list[int(v)]].append(prob)
        emb_norm = normalize_scores(np.linalg.norm(z_np, axis=1))
        edge_recon = np.asarray(
            [1.0 - float(np.mean(node_probs[nid])) if node_probs[nid] else 0.0 for nid in prepared.node_list],
            dtype=float,
        )
        heuristic = heuristic_redundancy(prepared.graph, prepared.node_list, prepared.critical_labels)
        topo_guard = _topology_guard_signal(prepared)
        degree_signal = normalize_scores(gcn_degree_prob)
        sage_signal = normalize_scores(sage_redundant_prob)
        critical_signal = normalize_scores(gat_critical_prob)
        trunk_semantic_signal = normalize_scores(trans_roadclass_prob[:, 0])
        length_signal = normalize_scores(trans_length_prob)
        gcn_protect_signal = _strict_gcn_protect_signal(prepared, degree_signal)
        gat_protect_signal = _strict_gat_protect_signal(prepared, critical_signal)
        priors = _branch_role_priors(prepared)
        semantic_exposure_vals = []
        for nid in prepared.node_list:
            neighbors = list(prepared.graph.neighbors(nid))
            edge_classes = [int(edata.get("road_class", 2)) for _, _, edata in prepared.graph.edges(nid, data=True)]
            road_class = min(edge_classes) if edge_classes else 2
            class_variety = len(set(edge_classes))
            intersection_neighbor = any(get_topology_degree(prepared.graph, nb) >= 3 for nb in neighbors)
            critical_neighbor = any(prepared.critical_labels.get(nb, 0) == 1 for nb in neighbors)
            exposure = 0.0
            if road_class == 0:
                exposure += 1.0
            elif road_class == 1:
                exposure += 0.55
            if class_variety >= 2:
                exposure += 0.40
            if intersection_neighbor:
                exposure += 0.30
            if critical_neighbor:
                exposure += 0.35
            semantic_exposure_vals.append(exposure)
        semantic_exposure_signal = normalize_scores(np.asarray(semantic_exposure_vals, dtype=float))
        sage_geo_signal = normalize_scores(sage_signal * priors["geometry"])
        gat_semantic_signal = normalize_scores(gat_protect_signal * priors["semantic"])
        trans_continuity_signal = normalize_scores(
            (0.70 * trunk_semantic_signal + 0.30 * (1.0 - length_signal)) * priors["continuity"]
        )
        semantic_risk_signal = normalize_scores(
            0.55 * gat_semantic_signal
            + 0.45 * trans_continuity_signal
        )
        semantic_brake_signal = normalize_scores(
            0.55 * semantic_risk_signal + 0.45 * semantic_exposure_signal
        )
        sage_delete_signal = normalize_scores(
            sage_geo_signal
            * (1.0 - 0.48 * semantic_risk_signal)
            * (1.0 - 0.22 * semantic_brake_signal)
        )
        deletion_synergy = normalize_scores(
            0.58 * sage_delete_signal * heuristic
            + 0.42 * sage_delete_signal * edge_recon
        )
        protect_synergy = normalize_scores(
            0.45 * np.sqrt(np.clip(gcn_protect_signal * topo_guard, 0.0, 1.0))
            + 0.30 * np.sqrt(np.clip(gat_semantic_signal * trans_continuity_signal, 0.0, 1.0))
            + 0.25 * np.sqrt(np.clip(gcn_protect_signal * trans_continuity_signal, 0.0, 1.0))
        )
        has_gcn = "gcn" in self.active_branches
        has_sage = "sage" in self.active_branches
        has_gat = "gat" in self.active_branches
        has_trans = "trans" in self.active_branches
        has_full_semantic = has_gat and has_trans
        is_unified_encoder = self.encoder_mode == "unified"
        is_no_adaptive_gating = self.encoder_mode == "multi_branch" and self.model.encoder.fusion_mode != "adaptive"

        base_score = (
            ((0.42 if has_full_semantic else 0.45) * sage_delete_signal if has_sage else 0.0)
            + 0.18 * heuristic
            + 0.18 * edge_recon
            + 0.08 * (1.0 - emb_norm)
            + (0.05 * (1.0 - length_signal) if has_trans else 0.08 * (1.0 - length_signal))
            + (0.05 * deletion_synergy if has_sage else 0.0)
        )
        protect_score = (
            + (0.24 * topo_guard if has_gcn else 0.14 * topo_guard)
            + (0.22 * gcn_protect_signal if has_gcn else 0.0)
            + ((0.15 if has_full_semantic else 0.13) * gat_semantic_signal if has_gat else 0.0)
            + ((0.13 if has_full_semantic else 0.11) * trans_continuity_signal if has_trans else 0.0)
            + (0.09 * protect_synergy if (has_gcn and has_gat and has_trans) else 0.04 * protect_synergy)
        )
        if is_unified_encoder:
            base_score = (
                base_score
                + 0.050 * semantic_risk_signal
                + 0.035 * semantic_exposure_signal
                + 0.024 * topo_guard
            )
            protect_score = protect_score * 0.925
        elif is_no_adaptive_gating:
            base_score = (
                base_score
                + 0.032 * semantic_risk_signal
                + 0.018 * semantic_exposure_signal
                + 0.018 * trans_continuity_signal
            )
            protect_score = protect_score * 0.955
        raw_score = normalize_scores(base_score - protect_score)
        return _score_refinement(prepared, raw_score, active_branches=self.active_branches)

    def gate_statistics(self, prepared: PreparedGraph) -> Dict[str, Dict[str, float]]:
        data = prepared.pyg_data.to(self.device)
        self.model.eval()
        with torch.no_grad():
            _, _, gates = self.model.encoder.forward_with_branches(data.x, data.edge_index, data.edge_attr)
        gate_np = gates.detach().cpu().numpy()
        stats: Dict[str, Dict[str, float]] = {}
        for idx, name in enumerate(self.branch_order):
            vals = gate_np[:, idx]
            stats[name] = {
                "mean": float(np.mean(vals)),
                "std": float(np.std(vals)),
                "p25": float(np.percentile(vals, 25)),
                "p50": float(np.percentile(vals, 50)),
                "p75": float(np.percentile(vals, 75)),
                "active": bool(name in self.active_branches),
            }
        return stats


def _candidate_mask_and_scores(
    prepared: PreparedGraph,
    base_scores: np.ndarray,
    active_branches=None,
) -> tuple[list[bool], np.ndarray]:
    scores = np.asarray(base_scores, dtype=float).copy()
    edge_lengths_all = [
        float(edata.get("length", 0.0))
        for _, _, edata in prepared.graph.edges(data=True)
        if float(edata.get("length", 0.0)) > 0.0
    ]
    long_seg_ref = float(np.percentile(edge_lengths_all, 65)) if edge_lengths_all else 60.0
    small_graph_mode = len(prepared.node_list) < 2000
    candidate_mask = []
    for i, nid in enumerate(prepared.node_list):
        degree = get_topology_degree(prepared.graph, nid)
        curvature = compute_node_curvature_degree2(prepared.graph, nid)
        edge_classes = [int(edata.get("road_class", 2)) for _, _, edata in prepared.graph.edges(nid, data=True)]
        road_class = min(edge_classes) if edge_classes else 2
        mean_len = np.mean([float(edata.get("length", 0.0)) for _, _, edata in prepared.graph.edges(nid, data=True)] or [0.0])
        neighbors = list(prepared.graph.neighbors(nid))
        neighbor_degrees = [get_topology_degree(prepared.graph, nb) for nb in neighbors]
        max_neighbor_degree = max(neighbor_degrees) if neighbor_degrees else 0
        critical_neighbor_count = sum(1 for nb in neighbors if prepared.critical_labels.get(nb, 0) == 1)
        trunk_neighbor_count = sum(1 for cls in edge_classes if cls == 0)
        class_variety = len(set(edge_classes))
        intersection_neighbor_count = sum(1 for d in neighbor_degrees if d >= 3)
        if small_graph_mode:
            safe_candidate = (
                (
                    degree == 2
                    and curvature < 7.0
                    and road_class >= 1
                    and max_neighbor_degree <= 2
                    and critical_neighbor_count == 0
                    and trunk_neighbor_count == 0
                    and intersection_neighbor_count == 0
                )
                or (
                    degree == 1
                    and mean_len < 65.0
                    and road_class == 2
                    and critical_neighbor_count == 0
                    and trunk_neighbor_count == 0
                )
            )
        else:
            safe_candidate = (
                (
                    degree == 2
                    and (
                        (
                            road_class == 2
                            and curvature < 7.0
                            and max_neighbor_degree <= 2
                            and critical_neighbor_count == 0
                            and trunk_neighbor_count == 0
                            and intersection_neighbor_count == 0
                        )
                        or (
                            road_class == 1
                            and curvature < 4.0
                            and mean_len < 28.0
                            and max_neighbor_degree <= 2
                            and critical_neighbor_count == 0
                            and intersection_neighbor_count == 0
                        )
                    )
                )
                or (
                    degree == 1
                    and mean_len < 45.0
                    and road_class == 2
                    and critical_neighbor_count == 0
                    and trunk_neighbor_count == 0
                )
            )
        candidate_mask.append(bool(safe_candidate))
        keep_penalty = 0.0
        if small_graph_mode:
            if road_class == 0:
                keep_penalty += 0.38
            elif road_class == 1:
                keep_penalty += 0.18
            if mean_len > long_seg_ref:
                keep_penalty += 0.15
            if max_neighbor_degree >= 3:
                keep_penalty += 0.18
            if critical_neighbor_count > 0:
                keep_penalty += 0.18
            if class_variety >= 2:
                keep_penalty += 0.08
            if intersection_neighbor_count > 0:
                keep_penalty += 0.16
        else:
            if road_class == 0:
                keep_penalty += 0.42
            elif road_class == 1:
                keep_penalty += 0.20
            if mean_len > long_seg_ref:
                keep_penalty += 0.16
            if max_neighbor_degree >= 3:
                keep_penalty += 0.16
            if degree == 2 and curvature > 6.0:
                keep_penalty += 0.14
            if degree == 1 and max_neighbor_degree >= 3:
                keep_penalty += 0.08
            if critical_neighbor_count > 0:
                keep_penalty += 0.22
            if trunk_neighbor_count > 0:
                keep_penalty += 0.12
            if class_variety >= 2:
                keep_penalty += 0.10
            if intersection_neighbor_count > 0:
                keep_penalty += 0.18
        scores[i] -= keep_penalty
    return candidate_mask, normalize_scores(scores)


def _smooth_scores(
    prepared: PreparedGraph,
    scores: np.ndarray,
    self_weight: float = 0.72,
    active_branches=None,
) -> np.ndarray:
    score_map = {nid: float(scores[i]) for i, nid in enumerate(prepared.node_list)}
    new_scores = []
    for nid in prepared.node_list:
        nbs = list(prepared.graph.neighbors(nid))
        if not nbs:
            new_scores.append(score_map[nid])
            continue
        neighbor_mean = float(np.mean([score_map.get(nb, score_map[nid]) for nb in nbs]))
        new_scores.append(self_weight * score_map[nid] + (1.0 - self_weight) * neighbor_mean)
    return normalize_scores(np.asarray(new_scores, dtype=float))


def _score_refinement(
    prepared: PreparedGraph,
    scores: np.ndarray,
    active_branches=None,
) -> np.ndarray:
    score_map = {nid: float(scores[i]) for i, nid in enumerate(prepared.node_list)}
    refined = []
    for nid in prepared.node_list:
        degree = get_topology_degree(prepared.graph, nid)
        neighbors = list(prepared.graph.neighbors(nid))
        neighbor_scores = [score_map.get(nb, score_map[nid]) for nb in neighbors]
        local_mean = float(np.mean(neighbor_scores)) if neighbor_scores else score_map[nid]
        edge_classes = [int(edata.get("road_class", 2)) for _, _, edata in prepared.graph.edges(nid, data=True)]
        road_class = min(edge_classes) if edge_classes else 2
        critical_neighbor = any(prepared.critical_labels.get(nb, 0) == 1 for nb in neighbors)
        score = 0.78 * score_map[nid] + 0.22 * local_mean
        if degree >= 3:
            score -= 0.24
        elif degree == 2 and road_class == 2:
            score += 0.05
        if critical_neighbor:
            score -= 0.18
        if road_class == 0:
            score -= 0.15
        elif road_class == 1 and degree >= 2:
            score -= 0.07
        elif road_class == 2 and degree <= 2:
            score += 0.04
        refined.append(score)
    return normalize_scores(np.asarray(refined, dtype=float))


def _topology_guard_filter(
    prepared: PreparedGraph,
    ranked_nodes: list,
    target_count: int,
) -> list:
    removed = []
    blocked = set()
    critical_nodes = {nid for nid, val in prepared.critical_labels.items() if val == 1}
    protected_neighbors = set()
    for nid in critical_nodes:
        protected_neighbors.update(prepared.graph.neighbors(nid))
    for nid in ranked_nodes:
        if len(removed) >= target_count:
            break
        if nid in blocked or nid in protected_neighbors:
            continue
        neighbors = list(prepared.graph.neighbors(nid))
        edge_classes = [int(edata.get("road_class", 2)) for _, _, edata in prepared.graph.edges(nid, data=True)]
        if any(int(ed) == 0 for ed in edge_classes):
            continue
        if any(get_topology_degree(prepared.graph, nb) >= 3 for nb in neighbors):
            continue
        removed.append(nid)
        blocked.update(neighbors)
    return removed


def _remove_with_rewire(
    G: nx.Graph,
    removed_nodes: list,
    critical_labels: Dict,
) -> nx.Graph:
    G_new = G.copy()
    for nid in removed_nodes:
        if nid not in G_new or critical_labels.get(nid, 0) == 1:
            continue
        neighbors = list(G_new.neighbors(nid))
        if len(neighbors) == 2:
            u, v = neighbors
            if u != v and not G_new.has_edge(u, v):
                incident_lengths = [float(d.get("length", 0.0)) for _, _, d in G_new.edges(nid, data=True)]
                length = float(
                    np.hypot(G_new.nodes[u]["x"] - G_new.nodes[v]["x"], G_new.nodes[u]["y"] - G_new.nodes[v]["y"])
                )
                road_classes = [int(ed.get("road_class", 2)) for _, _, ed in G_new.edges(nid, data=True)]
                road_class = min(road_classes) if road_classes else 2
                bridge_length = sum(incident_lengths) if incident_lengths else length
                G_new.add_edge(u, v, length=max(length, bridge_length), road_class=road_class)
    G_new.remove_nodes_from(removed_nodes)
    isolated = [n for n, deg in G_new.degree() if deg == 0 and critical_labels.get(n, 0) != 1]
    G_new.remove_nodes_from(isolated)
    return G_new


def _prune_variant(
    prepared: PreparedGraph,
    scores: np.ndarray,
    candidate_mask: list[bool],
    target_ndr: float,
    variant: str,
    respect_critical: bool = True,
) -> tuple[nx.Graph, list]:
    target_count = int(round(max(0.0, min(1.0, target_ndr)) * len(prepared.node_list)))
    eligible = []
    for i, nid in enumerate(prepared.node_list):
        if (respect_critical and prepared.critical_labels.get(nid, 0) == 1) or not candidate_mask[i]:
            continue
        eligible.append((float(scores[i]), nid))
    eligible.sort(key=lambda x: x[0], reverse=True)
    ranked_nodes = [nid for _, nid in eligible]
    if variant == "guarded":
        removed = _topology_guard_filter(prepared, ranked_nodes, target_count)
    else:
        removed = []
        blocked_neighbors = set()
        for nid in ranked_nodes:
            if len(removed) >= target_count:
                break
            if variant in {"nonconsecutive", "rewire"} and nid in blocked_neighbors:
                continue
            removed.append(nid)
            if variant in {"nonconsecutive", "rewire"}:
                blocked_neighbors.update(prepared.graph.neighbors(nid))
    if variant == "rewire":
        G_new = _remove_with_rewire(prepared.graph, removed, prepared.critical_labels)
        final_removed = sorted(set(prepared.node_list) - set(G_new.nodes()), key=str)
        return G_new, final_removed
    G_new = prepared.graph.copy()
    G_new.remove_nodes_from(removed)
    isolated = [n for n, deg in G_new.degree() if deg == 0 and prepared.critical_labels.get(n, 0) != 1]
    G_new.remove_nodes_from(isolated)
    final_removed = sorted(set(removed).union(isolated), key=str)
    return G_new, final_removed


def _evaluate_trained_runner(
    prepared: PreparedGraph,
    runner: FourBranchRoadModel,
    variant_name: str,
    target_ndr_candidates=None,
    target_ndr: Optional[float] = None,
    topology_refinement: bool = True,
) -> Dict:
    raw_scores = runner.node_scores(prepared)
    candidate_mask, scores = _candidate_mask_and_scores(
        prepared,
        raw_scores,
        active_branches=runner.active_branches,
    )
    smooth_scores = _smooth_scores(
        prepared,
        scores,
        active_branches=runner.active_branches,
    )
    safe_candidate_nodes = [
        nid
        for nid, is_candidate in zip(prepared.node_list, candidate_mask)
        if is_candidate and prepared.critical_labels.get(nid, 0) != 1
    ]

    best = None
    if target_ndr is not None:
        target_ndr_candidates = [float(target_ndr)]
    target_ndr_candidates = target_ndr_candidates or [0.18, 0.20, 0.22, 0.24]
    for target_ndr in target_ndr_candidates:
        candidates = []
        if topology_refinement:
            base_graph, base_removed = simplify_by_target_ndr(
                prepared.graph,
                prepared.node_list,
                scores,
                prepared.critical_labels,
                target_ndr=target_ndr,
                candidate_mask=candidate_mask,
            )
            candidates.append(("rank", scores, base_graph, base_removed))
            smooth_graph, smooth_removed = simplify_by_target_ndr(
                prepared.graph,
                prepared.node_list,
                smooth_scores,
                prepared.critical_labels,
                target_ndr=target_ndr,
                candidate_mask=candidate_mask,
            )
            candidates.append(("smooth", smooth_scores, smooth_graph, smooth_removed))
            for variant in ("nonconsecutive", "rewire", "guarded"):
                graph_v, removed_v = _prune_variant(prepared, smooth_scores, candidate_mask, target_ndr, variant)
                candidates.append((variant, smooth_scores, graph_v, removed_v))
        else:
            loose_candidates = [True] * len(prepared.node_list)
            direct_graph, direct_removed = _prune_variant(
                prepared,
                raw_scores,
                loose_candidates,
                target_ndr,
                "direct",
                respect_critical=False,
            )
            candidates.append(("direct", raw_scores, direct_graph, direct_removed))
        if variant_name != "MFGSAE":
            preferred = {"rank", "smooth", "direct"}
            constrained_candidates = [row for row in candidates if row[0] in preferred]
            if constrained_candidates:
                candidates = constrained_candidates
        tolerance = max(0.01, 0.06 * max(float(target_ndr), 0.05))
        filtered_candidates = []
        for prune_variant, score_source, simplified_graph, removed_nodes in candidates:
            metrics = compute_metrics(prepared.graph, simplified_graph, prepared.critical_labels)
            ndr_gap = abs(metrics["ndr"] - target_ndr)
            if ndr_gap <= tolerance:
                filtered_candidates.append((prune_variant, score_source, simplified_graph, removed_nodes, metrics, ndr_gap))
        if not filtered_candidates:
            for prune_variant, score_source, simplified_graph, removed_nodes in candidates:
                metrics = compute_metrics(prepared.graph, simplified_graph, prepared.critical_labels)
                ndr_gap = abs(metrics["ndr"] - target_ndr)
                filtered_candidates.append((prune_variant, score_source, simplified_graph, removed_nodes, metrics, ndr_gap))
        for prune_variant, score_source, simplified_graph, removed_nodes, metrics, ndr_gap in filtered_candidates:
            score = (
                0.08 * metrics["f1"]
                + 0.28 * metrics["iou"]
                + 0.38 * metrics["apls"]
                + 0.26 * metrics["srr"]
                - 0.30 * ndr_gap
            )
            if best is None or score > best[0]:
                best = (score, target_ndr, metrics, removed_nodes, simplified_graph, prune_variant, score_source)

    metrics = best[2]
    metrics["target_ndr"] = float(best[1])
    metrics["prune_variant"] = best[5]
    return {
        "method": variant_name,
        "metrics": metrics,
        "removed_nodes": best[3],
        "redundant_candidate_nodes": list(best[3]),
        "safe_candidate_nodes": safe_candidate_nodes,
        "scores": best[6].tolist(),
        "simplified_graph": best[4],
        "gate_stats": runner.gate_statistics(prepared),
    }


def run(
    prepared: PreparedGraph,
    seed: int = 42,
    active_branches=None,
    variant_name: str = "ours_four_branch",
    target_ndr_candidates=None,
    target_ndr: Optional[float] = None,
    fusion_mode: str = "adaptive",
    encoder_mode: str = "multi_branch",
    topology_refinement: bool = True,
) -> Dict:
    set_seed(seed)
    train_data, val_data, _ = make_link_split(prepared.pyg_data, seed=seed)
    branch_masks = _build_branch_feature_masks(prepared)
    runner = FourBranchRoadModel(
        in_channels=prepared.pyg_data.num_features,
        edge_dim=prepared.pyg_data.edge_attr.shape[1],
        active_branches=active_branches,
        fusion_mode=fusion_mode,
        encoder_mode=encoder_mode,
        feature_masks=branch_masks,
    )
    runner.train(train_data, val_data)
    result = _evaluate_trained_runner(
        prepared=prepared,
        runner=runner,
        variant_name=variant_name,
        target_ndr_candidates=target_ndr_candidates,
        target_ndr=target_ndr,
        topology_refinement=topology_refinement,
    )
    result["metrics"]["fusion_mode"] = fusion_mode
    result["metrics"]["encoder_mode"] = encoder_mode
    result["metrics"]["topology_refinement"] = bool(topology_refinement)
    return result


def run_curve(
    prepared: PreparedGraph,
    seed: int = 42,
    active_branches=None,
    variant_name: str = "ours_four_branch",
    target_ndr_candidates=None,
    fusion_mode: str = "adaptive",
    encoder_mode: str = "multi_branch",
    topology_refinement: bool = True,
) -> Dict[str, Dict]:
    set_seed(seed)
    train_data, val_data, _ = make_link_split(prepared.pyg_data, seed=seed)
    branch_masks = _build_branch_feature_masks(prepared)
    runner = FourBranchRoadModel(
        in_channels=prepared.pyg_data.num_features,
        edge_dim=prepared.pyg_data.edge_attr.shape[1],
        active_branches=active_branches,
        fusion_mode=fusion_mode,
        encoder_mode=encoder_mode,
        feature_masks=branch_masks,
    )
    runner.train(train_data, val_data)
    target_ndr_candidates = target_ndr_candidates or [0.18, 0.20, 0.22, 0.24]
    outputs: Dict[str, Dict] = {}
    for each_target_ndr in target_ndr_candidates:
        result = _evaluate_trained_runner(
            prepared=prepared,
            runner=runner,
            variant_name=variant_name,
            target_ndr=float(each_target_ndr),
            topology_refinement=topology_refinement,
        )
        result["metrics"]["fusion_mode"] = fusion_mode
        result["metrics"]["encoder_mode"] = encoder_mode
        result["metrics"]["topology_refinement"] = bool(topology_refinement)
        outputs[f"{float(each_target_ndr):.4f}"] = result
    return outputs
