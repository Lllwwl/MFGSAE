import json
import logging
import math
import random
import xml.etree.ElementTree as ET
from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import networkx as nx
import numpy as np
import osmnx as ox
import torch
from scipy.stats import entropy
from shapely.geometry import LineString
from sklearn.metrics import f1_score, precision_score, recall_score
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import DBSCAN
from torch_geometric.data import Data
from torch_geometric.transforms import RandomLinkSplit


logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

TRUNK_TYPES = {
    "motorway",
    "motorway_link",
    "trunk",
    "trunk_link",
    "primary",
    "primary_link",
}
SKELETON_TYPES = {
    "secondary",
    "secondary_link",
    "tertiary",
    "tertiary_link",
    "residential",
    "living_street",
    "unclassified",
}
LOCAL_TYPES = {"service", "track", "path", "footway", "cycleway"}
VALID_TYPES = TRUNK_TYPES | SKELETON_TYPES | LOCAL_TYPES

IOU_GRID_SIZE = 5.0
APLS_SAMPLE_SIZE = 80
DEFAULT_TARGET_NDR = 0.18


@dataclass
class PreparedGraph:
    graph: nx.Graph
    critical_labels: Dict
    node_list: List
    pyg_data: Data
    feature_names: List[str]
    feature_groups: Dict[str, List[int]]


def set_seed(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _highway_value(hw):
    if isinstance(hw, list):
        return hw[0] if hw else None
    return hw


def _iter_incident_edge_data(G: nx.Graph, node) -> Iterable[dict]:
    if node not in G:
        return
    seen = set()

    def _yield(edge_iter):
        for item in edge_iter:
            if len(item) == 4:
                u, v, k, data = item
                edge_id = (u, v, k)
            else:
                u, v, data = item
                edge_id = (u, v, None)
            if edge_id in seen:
                continue
            seen.add(edge_id)
            yield data

    if G.is_multigraph():
        for data in _yield(G.edges(node, keys=True, data=True)):
            yield data
        if G.is_directed():
            for data in _yield(G.in_edges(node, keys=True, data=True)):
                yield data
    else:
        for data in _yield(G.edges(node, data=True)):
            yield data
        if G.is_directed():
            for data in _yield(G.in_edges(node, data=True)):
                yield data


def get_topology_neighbors(G: nx.Graph, node) -> List:
    if node not in G:
        return []
    nbs = set()
    try:
        nbs.update(G.neighbors(node))
    except Exception:
        pass
    if G.is_directed():
        try:
            nbs.update(G.predecessors(node))
        except Exception:
            pass
    nbs.discard(node)
    return list(nbs)


def get_topology_degree(G: nx.Graph, node) -> int:
    return len(get_topology_neighbors(G, node))


def load_graph(osm_file: str) -> nx.Graph:
    logging.info("Loading OSM graph: %s", osm_file)
    G = ox.graph_from_xml(osm_file, simplify=False, retain_all=True)
    if isinstance(G, tuple):
        G = G[0]
    if "crs" not in G.graph or str(G.graph["crs"]).lower() == "epsg:4326":
        G = ox.project_graph(G, to_crs="EPSG:3857")
    return G


def ensure_edge_geometry_and_length(G: nx.Graph) -> None:
    for u, v, data in G.edges(data=True):
        if "geometry" not in data:
            data["geometry"] = LineString(
                [(G.nodes[u]["x"], G.nodes[u]["y"]), (G.nodes[v]["x"], G.nodes[v]["y"])]
            )
        if "length" not in data or data["length"] in (None, 0):
            data["length"] = float(
                np.hypot(G.nodes[u]["x"] - G.nodes[v]["x"], G.nodes[u]["y"] - G.nodes[v]["y"])
            )


def process_road_network(G: nx.Graph) -> nx.Graph:
    edges_to_keep = []
    if G.is_multigraph():
        for u, v, k, d in G.edges(keys=True, data=True):
            hw = _highway_value(d.get("tags", {}).get("highway", d.get("highway")))
            if hw in VALID_TYPES:
                edges_to_keep.append((u, v, k))
    else:
        for u, v, d in G.edges(data=True):
            hw = _highway_value(d.get("tags", {}).get("highway", d.get("highway")))
            if hw in VALID_TYPES:
                edges_to_keep.append((u, v))
    G_new = G.edge_subgraph(edges_to_keep).copy() if edges_to_keep else G.copy()
    ensure_edge_geometry_and_length(G_new)
    for u, v, d in G_new.edges(data=True):
        hw = _highway_value(d.get("tags", {}).get("highway", d.get("highway")))
        if hw in TRUNK_TYPES:
            d["road_class"] = 0
        elif hw in SKELETON_TYPES:
            d["road_class"] = 1
        else:
            d["road_class"] = 2
        d["highway"] = hw
    return G_new


def replace_with_centroids(G: nx.Graph, xml_root: ET.Element, auto_ratio: float = 0.03) -> Tuple[nx.Graph, Set]:
    edge_geoms = {}
    for u, v, data in G.edges(data=True):
        if "geometry" in data:
            edge_geoms[(u, v)] = data["geometry"]
            edge_geoms[(v, u)] = data["geometry"]

    coords = np.array([[d["x"], d["y"]] for _, d in G.nodes(data=True)], dtype=float)
    if len(coords) == 0:
        return G, set()
    span = float(np.hypot(coords[:, 0].ptp(), coords[:, 1].ptp()))
    eps = max(6.0, span * auto_ratio)

    # Protect nodes that participate in any road way so centroid replacement
    # cannot break the visible road skeleton.
    protected_road_nodes = set()
    for way in xml_root.findall("way"):
        tags = {t.attrib["k"]: t.attrib["v"] for t in way.findall("tag")}
        if "highway" not in tags:
            continue
        for nd in way.findall("nd"):
            try:
                protected_road_nodes.add(int(nd.attrib["ref"]))
            except Exception:
                continue

    centroids = set()
    to_remove = []
    for way in xml_root.findall("way"):
        node_refs = [int(nd.attrib["ref"]) for nd in way.findall("nd")]
        if len(node_refs) < 4 or node_refs[0] != node_refs[-1]:
            continue
        tags = {t.attrib["k"]: t.attrib["v"] for t in way.findall("tag")}
        if not set(tags.keys()) & {"building", "water", "leisure", "landuse", "amenity"}:
            continue
        orig_nodes = [n for n in node_refs if n in G.nodes]
        if len(orig_nodes) < 3:
            continue

        pts = np.array([[G.nodes[n]["x"], G.nodes[n]["y"]] for n in orig_nodes])
        labels = DBSCAN(eps=eps, min_samples=1).fit_predict(pts)
        for lbl in set(labels):
            part = pts[labels == lbl]
            cx, cy = part.mean(axis=0)
            ctype = (
                "building"
                if "building" in tags
                else "water"
                if "water" in tags
                else "park"
                if "leisure" in tags
                else "default"
            )
            node_id = f"centroid_{way.attrib.get('id', 'unknown')}_{lbl}"
            G.add_node(node_id, x=float(cx), y=float(cy), tags={"centroid": "True", "type": ctype})
            centroids.add(node_id)
        removable_nodes = [n for n in orig_nodes if n not in protected_road_nodes]
        to_remove.extend(removable_nodes)

    G.remove_nodes_from(list(set(to_remove)))
    ensure_edge_geometry_and_length(G)
    for u, v, data in G.edges(data=True):
        if (u, v) in edge_geoms:
            data["geometry"] = edge_geoms[(u, v)]
    return G, centroids


def label_critical_nodes(G: nx.Graph) -> Dict:
    critical_labels = {}
    endpoint_length = 60.0
    curvature_threshold = 8.0

    for node in G.nodes():
        tags = G.nodes[node].get("tags", {})
        if str(tags.get("centroid", "False")).lower() == "true":
            critical_labels[node] = 1
            continue

        protected_structure = False
        for edata in _iter_incident_edge_data(G, node):
            if not isinstance(edata, dict):
                continue
            bridge = edata.get("bridge")
            tunnel = edata.get("tunnel")
            junction = edata.get("junction")
            if bridge is None and isinstance(edata.get("tags"), dict):
                bridge = edata["tags"].get("bridge")
            if tunnel is None and isinstance(edata.get("tags"), dict):
                tunnel = edata["tags"].get("tunnel")
            if junction is None and isinstance(edata.get("tags"), dict):
                junction = edata["tags"].get("junction")
            if str(bridge).lower() in ("yes", "true", "1"):
                protected_structure = True
            if str(tunnel).lower() in ("yes", "true", "1"):
                protected_structure = True
            if str(junction).lower() == "roundabout":
                protected_structure = True
        if protected_structure:
            critical_labels[node] = 1
            continue

        degree = get_topology_degree(G, node)
        if degree >= 3:
            critical_labels[node] = 1
            continue

        if degree == 1:
            lengths = []
            for edata in _iter_incident_edge_data(G, node):
                try:
                    lengths.append(float(edata.get("length", 0.0)))
                except Exception:
                    pass
            critical_labels[node] = 1 if lengths and max(lengths) > endpoint_length else 0
            continue

        if degree == 2:
            nbs = get_topology_neighbors(G, node)
            if len(nbs) != 2:
                critical_labels[node] = 0
                continue
            n1, n2 = nbs
            try:
                p = np.array([G.nodes[node]["x"], G.nodes[node]["y"]], dtype=float)
                p1 = np.array([G.nodes[n1]["x"], G.nodes[n1]["y"]], dtype=float)
                p2 = np.array([G.nodes[n2]["x"], G.nodes[n2]["y"]], dtype=float)
                v1 = p1 - p
                v2 = p2 - p
                norm1 = np.linalg.norm(v1)
                norm2 = np.linalg.norm(v2)
                if norm1 == 0 or norm2 == 0:
                    critical_labels[node] = 0
                    continue
                dot = np.clip(np.dot(v1 / norm1, v2 / norm2), -1.0, 1.0)
                angle = np.degrees(np.arccos(dot))
                curvature = abs(180.0 - angle)
                critical_labels[node] = 1 if curvature > curvature_threshold else 0
            except Exception:
                critical_labels[node] = 0
            continue

        critical_labels[node] = 0
    return critical_labels


def compute_node_curvature_degree2(G: nx.Graph, node) -> float:
    try:
        nbs = get_topology_neighbors(G, node)
        if len(nbs) != 2:
            return 180.0
        n1, n2 = nbs
        p = np.array([G.nodes[node]["x"], G.nodes[node]["y"]], dtype=float)
        p1 = np.array([G.nodes[n1]["x"], G.nodes[n1]["y"]], dtype=float)
        p2 = np.array([G.nodes[n2]["x"], G.nodes[n2]["y"]], dtype=float)
        v1 = p1 - p
        v2 = p2 - p
        norm1 = np.linalg.norm(v1)
        norm2 = np.linalg.norm(v2)
        if norm1 == 0 or norm2 == 0:
            return 180.0
        angle = np.degrees(np.arccos(np.clip(np.dot(v1 / norm1, v2 / norm2), -1.0, 1.0)))
        return float(abs(180.0 - angle))
    except Exception:
        return 180.0


def build_node_features(G: nx.Graph) -> Tuple[np.ndarray, List, List[str]]:
    G_und = nx.Graph(G.to_undirected())
    clustering = nx.clustering(G_und)
    node_list = list(G.nodes())
    feature_names = [
        "x",
        "y",
        "topology_degree",
        "clustering",
        "mean_edge_length",
        "min_road_class",
        "is_centroid",
        "is_bridge_tunnel_roundabout",
        "curvature_score",
        "is_dead_end",
        "is_degree2",
        "is_high_degree",
        "has_trunk",
        "has_skeleton",
        "has_local",
    ]
    rows = []
    for node in node_list:
        tags = G.nodes[node].get("tags", {})
        degree = get_topology_degree(G, node)
        lengths = []
        classes = []
        highway_types = set()
        protected_structure = 0
        for edata in _iter_incident_edge_data(G, node):
            try:
                lengths.append(float(edata.get("length", 0.0)))
            except Exception:
                pass
            try:
                classes.append(int(edata.get("road_class", 2)))
            except Exception:
                classes.append(2)
            hw = _highway_value(edata.get("highway"))
            if hw is None and isinstance(edata.get("tags"), dict):
                hw = _highway_value(edata["tags"].get("highway"))
            if hw:
                highway_types.add(hw)
            for key in ("bridge", "tunnel", "junction"):
                val = edata.get(key)
                if val is None and isinstance(edata.get("tags"), dict):
                    val = edata["tags"].get(key)
                if str(val).lower() in ("yes", "true", "1", "roundabout"):
                    protected_structure = 1
        mean_len = float(np.mean(lengths)) if lengths else 0.0
        min_class = min(classes) if classes else 2
        curvature = compute_node_curvature_degree2(G, node)
        curvature_score = 1.0 - min(curvature, 90.0) / 90.0
        rows.append(
            [
                float(G.nodes[node].get("x", 0.0)),
                float(G.nodes[node].get("y", 0.0)),
                float(degree),
                float(clustering.get(node, 0.0)),
                mean_len,
                float(min_class),
                1.0 if str(tags.get("centroid", "False")).lower() == "true" else 0.0,
                float(protected_structure),
                float(curvature_score),
                1.0 if degree == 1 else 0.0,
                1.0 if degree == 2 else 0.0,
                1.0 if degree >= 3 else 0.0,
                1.0 if highway_types & TRUNK_TYPES else 0.0,
                1.0 if highway_types & SKELETON_TYPES else 0.0,
                1.0 if highway_types & LOCAL_TYPES else 0.0,
            ]
        )
    X = np.asarray(rows, dtype=float)
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    return X, node_list, feature_names


def build_feature_groups(feature_names: Sequence[str]) -> Dict[str, List[int]]:
    idx = {name: i for i, name in enumerate(feature_names)}
    topology = [
        idx["topology_degree"],
        idx["clustering"],
        idx["is_centroid"],
        idx["is_dead_end"],
        idx["is_degree2"],
        idx["is_high_degree"],
    ]
    geometry = [
        idx["x"],
        idx["y"],
        idx["mean_edge_length"],
        idx["curvature_score"],
    ]
    semantic = [
        idx["min_road_class"],
        idx["is_bridge_tunnel_roundabout"],
        idx["has_trunk"],
        idx["has_skeleton"],
        idx["has_local"],
    ]
    return {"topology": topology, "geometry": geometry, "semantic": semantic}


def scale_feature_groups(X: np.ndarray, feature_groups: Dict[str, List[int]]) -> np.ndarray:
    X_scaled = X.astype(float).copy()
    for _, cols in feature_groups.items():
        if not cols:
            continue
        cols_arr = X[:, cols]
        unique_vals = {float(v) for v in np.unique(cols_arr)}
        # Keep binary indicators as-is; scale continuous grouped features together.
        if unique_vals.issubset({0.0, 1.0}):
            X_scaled[:, cols] = cols_arr
        else:
            X_scaled[:, cols] = MinMaxScaler().fit_transform(cols_arr)
    return X_scaled


def build_edge_index_and_attr(G: nx.Graph, node_list: Sequence) -> Tuple[torch.Tensor, torch.Tensor]:
    id_map = {nid: i for i, nid in enumerate(node_list)}
    edges = []
    edge_attr = []
    for u, v, data in G.edges(data=True):
        if u not in id_map or v not in id_map:
            continue
        length = float(data.get("length", 0.0))
        road_class = float(data.get("road_class", 2))
        hw = _highway_value(data.get("highway"))
        if hw is None and isinstance(data.get("tags"), dict):
            hw = _highway_value(data["tags"].get("highway"))
        attr = [
            length,
            road_class,
            1.0 if hw in TRUNK_TYPES else 0.0,
            1.0 if hw in SKELETON_TYPES else 0.0,
            1.0 if hw in LOCAL_TYPES else 0.0,
        ]
        edges.append([id_map[u], id_map[v]])
        edge_attr.append(attr)
        edges.append([id_map[v], id_map[u]])
        edge_attr.append(attr)
    edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous()
    edge_attr_np = np.asarray(edge_attr, dtype=float)
    edge_attr_np = MinMaxScaler().fit_transform(edge_attr_np) if len(edge_attr_np) else np.zeros((0, 5))
    return edge_index, torch.tensor(edge_attr_np, dtype=torch.float)


def prepare_graph(osm_file: str, seed: int = 42, use_centroids: bool = True) -> PreparedGraph:
    set_seed(seed)
    G = load_graph(osm_file)
    G = process_road_network(G)
    xml_root = ET.parse(osm_file).getroot()
    if use_centroids:
        G, _ = replace_with_centroids(G, xml_root)
    ensure_edge_geometry_and_length(G)
    isolated = [n for n, deg in G.degree() if deg == 0 and str(G.nodes[n].get("tags", {}).get("centroid", "False")).lower() != "true"]
    G.remove_nodes_from(isolated)
    critical_labels = label_critical_nodes(G)
    X, node_list, feature_names = build_node_features(G)
    feature_groups = build_feature_groups(feature_names)
    x = torch.tensor(scale_feature_groups(X, feature_groups), dtype=torch.float)
    edge_index, edge_attr = build_edge_index_and_attr(G, node_list)
    topo_degree = torch.tensor(X[:, 2], dtype=torch.float)
    mean_edge_length = torch.tensor(X[:, 4], dtype=torch.float)
    min_road_class = torch.tensor(X[:, 5], dtype=torch.long)
    critical_target = torch.tensor([critical_labels.get(nid, 0) for nid in node_list], dtype=torch.float)
    redundancy_target = torch.tensor(
        [
            1.0
            if (
                critical_labels.get(nid, 0) == 0
                and int(X[i, 2]) == 2
                and float(X[i, 8]) > 0.78
                and float(X[i, 5]) >= 1.0
            )
            else 0.0
            for i, nid in enumerate(node_list)
        ],
        dtype=torch.float,
    )
    degree_target = topo_degree / max(float(topo_degree.max().item()), 1.0)
    length_target = mean_edge_length / max(float(mean_edge_length.max().item()), 1.0)
    pyg_data = Data(
        x=x,
        edge_index=edge_index,
        edge_attr=edge_attr,
        y_critical=critical_target,
        y_redundant=redundancy_target,
        y_degree=degree_target,
        y_length=length_target,
        y_roadclass=min_road_class,
    )
    return PreparedGraph(
        graph=G,
        critical_labels=critical_labels,
        node_list=node_list,
        pyg_data=pyg_data,
        feature_names=feature_names,
        feature_groups=feature_groups,
    )


def make_link_split(data: Data, seed: int = 42):
    set_seed(seed)
    splitter = RandomLinkSplit(
        num_val=0.1,
        num_test=0.1,
        is_undirected=True,
        add_negative_train_samples=True,
        split_labels=True,
    )
    return splitter(data)


def get_device() -> torch.device:
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def normalize_scores(arr: np.ndarray) -> np.ndarray:
    arr = np.asarray(arr, dtype=float)
    if arr.size == 0:
        return arr
    lo = float(arr.min())
    hi = float(arr.max())
    if hi - lo < 1e-12:
        return np.zeros_like(arr)
    return (arr - lo) / (hi - lo)


def heuristic_redundancy(G: nx.Graph, node_list: Sequence, critical_labels: Dict) -> np.ndarray:
    scores = []
    lengths = [float(d.get("length", 0.0)) for _, _, d in G.edges(data=True) if float(d.get("length", 0.0)) > 0]
    ref_len = float(np.percentile(lengths, 60)) if lengths else 80.0
    ref_len = max(ref_len, 1.0)
    for node in node_list:
        if critical_labels.get(node, 0) == 1:
            scores.append(0.0)
            continue
        degree = get_topology_degree(G, node)
        curvature = compute_node_curvature_degree2(G, node)
        curvature_score = 1.0 - min(curvature, 60.0) / 60.0
        edge_lengths = [float(edata.get("length", 0.0)) for edata in _iter_incident_edge_data(G, node)]
        mean_len = float(np.mean(edge_lengths)) if edge_lengths else ref_len
        shortness = 1.0 - min(mean_len / ref_len, 1.0)
        road_classes = [int(edata.get("road_class", 2)) for edata in _iter_incident_edge_data(G, node)]
        road_class = min(road_classes) if road_classes else 2
        low_level_bonus = 1.0 if road_class == 2 else 0.45 if road_class == 1 else 0.15
        if degree == 2:
            score = 0.45 * curvature_score + 0.30 * shortness + 0.25 * low_level_bonus
        elif degree == 1:
            score = 0.35 * shortness + 0.20 * low_level_bonus
        else:
            score = 0.15 * low_level_bonus
        scores.append(float(np.clip(score, 0.0, 1.0)))
    return np.asarray(scores, dtype=float)


def blend_scores(primary: np.ndarray, heuristic: np.ndarray, alpha: float) -> np.ndarray:
    return normalize_scores(alpha * normalize_scores(primary) + (1.0 - alpha) * normalize_scores(heuristic))


def simplify_by_scores(
    G: nx.Graph,
    node_list: Sequence,
    scores: np.ndarray,
    critical_labels: Dict,
    threshold: float,
) -> Tuple[nx.Graph, List]:
    removed = []
    score_map = {nid: float(scores[i]) for i, nid in enumerate(node_list)}
    for nid in node_list:
        if critical_labels.get(nid, 0) == 1:
            continue
        if score_map.get(nid, 0.0) >= threshold:
            removed.append(nid)
    G_new = G.copy()
    G_new.remove_nodes_from(removed)
    isolated = [n for n, deg in G_new.degree() if deg == 0 and critical_labels.get(n, 0) != 1]
    G_new.remove_nodes_from(isolated)
    removed = sorted(set(removed).union(isolated), key=str)
    return G_new, removed


def simplify_by_target_ndr(
    G: nx.Graph,
    node_list: Sequence,
    scores: np.ndarray,
    critical_labels: Dict,
    target_ndr: float,
    candidate_mask: Optional[Sequence[bool]] = None,
) -> Tuple[nx.Graph, List]:
    eligible = []
    for i, nid in enumerate(node_list):
        if critical_labels.get(nid, 0) == 1:
            continue
        if candidate_mask is not None and not bool(candidate_mask[i]):
            continue
        eligible.append((float(scores[i]), nid))
    if not eligible:
        return G.copy(), []
    eligible.sort(key=lambda x: x[0], reverse=True)

    desired_removed = int(round(max(0.0, min(1.0, target_ndr)) * len(node_list)))
    desired_removed = min(desired_removed, len(node_list))

    def build_with_count(count: int) -> Tuple[nx.Graph, List]:
        removed_nodes = [nid for _, nid in eligible[:count]]
        G_new = G.copy()
        G_new.remove_nodes_from(removed_nodes)
        isolated = [n for n, deg in G_new.degree() if deg == 0 and critical_labels.get(n, 0) != 1]
        G_new.remove_nodes_from(isolated)
        final_removed = sorted(set(removed_nodes).union(isolated), key=str)
        return G_new, final_removed

    lo, hi = 0, len(eligible)
    best_graph = G.copy()
    best_removed: List = []
    best_gap = float("inf")
    best_count = 0
    while lo <= hi:
        mid = (lo + hi) // 2
        graph_mid, removed_mid = build_with_count(mid)
        gap = abs(len(removed_mid) - desired_removed)
        if gap < best_gap or (gap == best_gap and len(removed_mid) <= desired_removed and mid > best_count):
            best_gap = gap
            best_graph = graph_mid
            best_removed = removed_mid
            best_count = mid
        if len(removed_mid) < desired_removed:
            lo = mid + 1
        elif len(removed_mid) > desired_removed:
            hi = mid - 1
        else:
            break
    return best_graph, best_removed


def compute_apls_score(G1: nx.Graph, G2: nx.Graph, sample_size: int = APLS_SAMPLE_SIZE) -> float:
    try:
        common_nodes = list(set(G1.nodes()).intersection(set(G2.nodes())))
        if len(common_nodes) < 2:
            return 0.0
        if len(common_nodes) > sample_size:
            common_nodes = random.sample(common_nodes, sample_size)
        G1_und = G1.to_undirected()
        G2_und = G2.to_undirected()
        penalties = []
        for i, u in enumerate(common_nodes):
            for v in common_nodes[i + 1 :]:
                try:
                    d1 = nx.shortest_path_length(G1_und, u, v, weight="length")
                except Exception:
                    continue
                try:
                    d2 = nx.shortest_path_length(G2_und, u, v, weight="length")
                except Exception:
                    penalties.append(1.0)
                    continue
                penalties.append(abs(d1 - d2) / max(d1, d2, 1e-8))
        return 1.0 - float(np.mean(penalties)) if penalties else 0.0
    except Exception:
        return 0.0


def compute_iou_score(G1: nx.Graph, G2: nx.Graph, grid_size: float = IOU_GRID_SIZE) -> float:
    try:
        grid_size = max(1.5, float(grid_size) * 0.5)

        def get_points(G):
            pts = []
            for _, data in G.nodes(data=True):
                if "x" in data and "y" in data:
                    pts.append((data["x"], data["y"]))
            for _, _, data in G.edges(data=True):
                geom = data.get("geometry")
                if geom is not None and hasattr(geom, "coords"):
                    coords = list(geom.coords)
                    if len(coords) >= 2:
                        for i in range(len(coords) - 1):
                            x1, y1 = coords[i]
                            x2, y2 = coords[i + 1]
                            seg_len = float(np.hypot(x2 - x1, y2 - y1))
                            steps = max(1, int(seg_len / max(grid_size * 0.7, 1.0)))
                            for t in np.linspace(0.0, 1.0, steps + 1):
                                pts.append((x1 + (x2 - x1) * t, y1 + (y2 - y1) * t))
                    else:
                        pts.extend(coords)
            return np.asarray(pts, dtype=float) if pts else np.asarray([], dtype=float)

        p1 = get_points(G1)
        p2 = get_points(G2)
        if len(p1) == 0 or len(p2) == 0:
            return 0.0
        all_pts = np.vstack([p1, p2])
        xmin, ymin = all_pts.min(axis=0)
        xmax, ymax = all_pts.max(axis=0)
        w = max(1, int((xmax - xmin) / grid_size) + 1)
        h = max(1, int((ymax - ymin) / grid_size) + 1)

        def to_grid(pts):
            grid = np.zeros((h, w), dtype=np.float32)
            for x, y in pts:
                xi = min(w - 1, max(0, int((x - xmin) / grid_size)))
                yi = min(h - 1, max(0, int((y - ymin) / grid_size)))
                grid[yi, xi] += 1.0
            return grid

        g1 = to_grid(p1)
        g2 = to_grid(p2)
        g1 = g1 / max(float(g1.max()), 1.0)
        g2 = g2 / max(float(g2.max()), 1.0)
        inter = np.minimum(g1, g2).sum()
        union = np.maximum(g1, g2).sum()
        return float(inter / union) if union > 0 else 0.0
    except Exception:
        return 0.0


def compute_srr_score(G1: nx.Graph, G2: nx.Graph) -> float:
    try:
        def dist_and_retention(G):
            edge_counter = defaultdict(float)
            length_counter = defaultdict(float)
            for _, _, data in G.edges(data=True):
                key = str(int(data.get("road_class", 2)))
                edge_counter[key] += 1.0
                length_counter[key] += float(data.get("length", 0.0))
            keys = sorted(set(edge_counter.keys()) | set(length_counter.keys()))
            if not keys:
                return np.asarray([1.0]), np.asarray([1.0]), ["0"]
            edge_arr = np.asarray([edge_counter.get(k, 0.0) for k in keys], dtype=float) + 1e-8
            len_arr = np.asarray([length_counter.get(k, 0.0) for k in keys], dtype=float) + 1e-8
            edge_arr /= edge_arr.sum()
            len_arr /= len_arr.sum()
            return edge_arr, len_arr, keys

        p1, l1, k1 = dist_and_retention(G1)
        p2, l2, k2 = dist_and_retention(G2)
        keys = sorted(set(k1) | set(k2))
        map_p1 = {k: p1[i] for i, k in enumerate(k1)}
        map_p2 = {k: p2[i] for i, k in enumerate(k2)}
        map_l1 = {k: l1[i] for i, k in enumerate(k1)}
        map_l2 = {k: l2[i] for i, k in enumerate(k2)}
        a1 = np.asarray([map_p1.get(k, 1e-8) for k in keys], dtype=float)
        a2 = np.asarray([map_p2.get(k, 1e-8) for k in keys], dtype=float)
        b1 = np.asarray([map_l1.get(k, 1e-8) for k in keys], dtype=float)
        b2 = np.asarray([map_l2.get(k, 1e-8) for k in keys], dtype=float)
        a1 /= a1.sum()
        a2 /= a2.sum()
        b1 /= b1.sum()
        b2 /= b2.sum()

        dist_sim = float(np.exp(-entropy(a1, a2)))
        len_sim = float(np.exp(-entropy(b1, b2)))

        retention = []
        for k in keys:
            base = max(map_l1.get(k, 1e-8), 1e-8)
            kept = map_l2.get(k, 1e-8)
            retention.append(min(kept / base, 1.0))
        retention = np.asarray(retention, dtype=float)
        retention_balance = float(1.0 - np.std(retention)) if len(retention) > 1 else float(retention[0])
        retention_balance = max(0.0, min(1.0, retention_balance))
        return 0.40 * dist_sim + 0.35 * len_sim + 0.25 * retention_balance
    except Exception:
        return 0.0


def compute_metrics(G_original: nx.Graph, G_simplified: nx.Graph, critical_labels: Dict) -> Dict[str, float]:
    node_list = list(G_original.nodes())
    removed_nodes = set(node_list) - set(G_simplified.nodes())
    total_nodes = len(node_list)
    ndr = len(removed_nodes) / total_nodes if total_nodes > 0 else 0.0
    y_true = [critical_labels.get(nid, 0) for nid in node_list]
    y_pred = [0 if nid in removed_nodes else 1 for nid in node_list]
    return {
        "ndr": float(ndr),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "iou": float(compute_iou_score(G_original, G_simplified)),
        "apls": float(compute_apls_score(G_original, G_simplified)),
        "srr": float(compute_srr_score(G_original, G_simplified)),
        "removed_count": int(len(removed_nodes)),
        "remaining_count": int(G_simplified.number_of_nodes()),
    }


def compute_fast_search_metrics(G_original: nx.Graph, G_simplified: nx.Graph, critical_labels: Dict) -> Dict[str, float]:
    node_list = list(G_original.nodes())
    removed_nodes = set(node_list) - set(G_simplified.nodes())
    total_nodes = len(node_list)
    ndr = len(removed_nodes) / total_nodes if total_nodes > 0 else 0.0
    y_true = [critical_labels.get(nid, 0) for nid in node_list]
    y_pred = [0 if nid in removed_nodes else 1 for nid in node_list]
    return {
        "ndr": float(ndr),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "iou": float(compute_iou_score(G_original, G_simplified)),
        "srr": float(compute_srr_score(G_original, G_simplified)),
        "removed_count": int(len(removed_nodes)),
        "remaining_count": int(G_simplified.number_of_nodes()),
    }


def composite_metric(metrics: Dict[str, float], target_ndr: float = DEFAULT_TARGET_NDR) -> float:
    ndr_penalty = abs(metrics["ndr"] - target_ndr)
    outside = max(0.0, abs(metrics["ndr"] - target_ndr) - 0.08)
    return (
        0.34 * metrics["f1"]
        + 0.24 * metrics["iou"]
        + 0.24 * metrics.get("apls", metrics["iou"])
        + 0.18 * metrics["srr"]
        - 0.12 * ndr_penalty
        - 1.25 * outside
    )


def select_best_threshold(
    G: nx.Graph,
    node_list: Sequence,
    scores: np.ndarray,
    critical_labels: Dict,
    thresholds: Sequence[float],
    target_ndr: float = DEFAULT_TARGET_NDR,
) -> Tuple[float, Dict[str, float], List]:
    best = None
    for thr in thresholds:
        G_simplified, removed = simplify_by_scores(G, node_list, scores, critical_labels, thr)
        metrics = compute_fast_search_metrics(G, G_simplified, critical_labels)
        metrics["composite"] = composite_metric(metrics, target_ndr=target_ndr)
        if best is None or metrics["composite"] > best[1]["composite"]:
            best = (float(thr), metrics, removed)
    return best


def save_result_json(path: str, payload: dict) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)


def get_positions(G: nx.Graph) -> Dict:
    pos = {}
    for node, data in G.nodes(data=True):
        if "x" in data and "y" in data:
            pos[node] = (data["x"], data["y"])
    if not pos:
        pos = nx.spring_layout(G, seed=42)
    return pos


def plot_before_after_comparison(
    G_original: nx.Graph,
    G_simplified: nx.Graph,
    critical_labels: Dict,
    removed_nodes: Sequence,
    save_path: str,
    scores: Optional[Sequence[float]] = None,
    node_list: Optional[Sequence] = None,
    redundant_candidate_nodes: Optional[Sequence] = None,
    title_prefix: str = "Road Simplification",
    display_threshold: Optional[float] = None,
    removed_nodes_as_redundant_in_before: bool = True,
) -> None:
    plt.rcParams["font.sans-serif"] = ["Times New Roman"]
    plt.rcParams["axes.unicode_minus"] = False
    pos = get_positions(G_original)
    removed_set = set(removed_nodes)
    redundant_candidate_set = set(redundant_candidate_nodes or [])
    score_map = {}
    if scores is not None and node_list is not None:
        score_map = {nid: float(scores[i]) for i, nid in enumerate(node_list) if i < len(scores)}
    if display_threshold is not None:
        display_thr = float(display_threshold)
    else:
        display_thr = float(np.quantile(list(score_map.values()), 0.82)) if score_map else 1.1

    road_color = "#999999"
    critical_color = "#FFB700"
    normal_color = "#555555"
    redundant_color = "#2176FF"
    removed_color = "#FF0000"
    critical_edge = "#C89200"

    fig, axes = plt.subplots(1, 2, figsize=(20, 10))
    fig.patch.set_facecolor("white")

    def plot_edges(ax, G, alpha=0.75, linewidth=0.8):
        for u, v in G.edges():
            if u in pos and v in pos:
                ax.plot(
                    [pos[u][0], pos[v][0]],
                    [pos[u][1], pos[v][1]],
                    color=road_color,
                    linewidth=linewidth,
                    alpha=alpha,
                    zorder=1,
                )

    def scatter(ax, pts, color, size, marker="o", alpha=0.9, edgecolors="none", linewidth=0.0, zorder=3):
        if not pts:
            return
        xs, ys = zip(*pts)
        ax.scatter(xs, ys, c=color, s=size, marker=marker, alpha=alpha, zorder=zorder, edgecolors=edgecolors, linewidth=linewidth)

    plot_edges(axes[0], G_original)
    plot_edges(axes[1], G_simplified)

    original_critical, original_normal, original_redundant = [], [], []
    for nid in G_original.nodes():
        if nid not in pos:
            continue
        xy = pos[nid]
        if critical_labels.get(nid, 0) == 1:
            original_critical.append(xy)
        elif nid in redundant_candidate_set:
            original_redundant.append(xy)
        elif removed_nodes_as_redundant_in_before and nid in removed_set:
            original_redundant.append(xy)
        elif score_map and score_map.get(nid, 0.0) >= display_thr:
            original_redundant.append(xy)
        else:
            original_normal.append(xy)

    scatter(axes[0], original_normal, normal_color, 40, alpha=0.72, zorder=2)
    scatter(axes[0], original_redundant, redundant_color, 26, alpha=0.88, zorder=3)
    scatter(axes[0], original_critical, critical_color, 34, alpha=1.00, edgecolors=critical_edge, linewidth=0.7, zorder=5)

    kept_critical, kept_normal, kept_redundant, removed_pts, removed_critical_pts = [], [], [], [], []
    for nid in G_original.nodes():
        if nid not in pos:
            continue
        xy = pos[nid]
        if critical_labels.get(nid, 0) == 1:
            if nid in G_simplified.nodes():
                kept_critical.append(xy)
            else:
                removed_critical_pts.append(xy)
        elif nid in removed_set:
            removed_pts.append(xy)
        elif nid in G_simplified.nodes():
            if nid in redundant_candidate_set:
                kept_redundant.append(xy)
            elif score_map and score_map.get(nid, 0.0) >= display_thr:
                kept_redundant.append(xy)
            else:
                kept_normal.append(xy)

    scatter(axes[1], kept_normal, normal_color, 40, alpha=0.72, zorder=2)
    scatter(axes[1], kept_redundant, redundant_color, 26, alpha=0.88, zorder=3)
    scatter(axes[1], removed_pts, removed_color, 40, marker="x", alpha=0.95, linewidth=2.0, zorder=4)
    scatter(axes[1], kept_critical, critical_color, 34, alpha=1.00, edgecolors=critical_edge, linewidth=0.7, zorder=6)
    scatter(axes[1], removed_critical_pts, critical_color, 36, alpha=1.00, edgecolors=critical_edge, linewidth=0.8, zorder=6)
    scatter(axes[1], removed_critical_pts, removed_color, 42, marker="x", alpha=0.98, linewidth=2.1, zorder=7)

    axes[0].set_title(f"{title_prefix}\n(a) Before Simplification", fontsize=15, fontweight="bold")
    axes[1].set_title(f"{title_prefix}\n(b) After Simplification", fontsize=15, fontweight="bold")
    for ax in axes:
        ax.axis("off")
        ax.set_aspect("equal")

    legend_elements = [
        Line2D([0], [0], color=road_color, lw=2.0, label="Road"),
        Line2D([0], [0], marker="o", color=critical_color, linestyle="", markersize=8,
               label="Critical Node", markerfacecolor=critical_color, markeredgecolor=critical_edge, markeredgewidth=0.7),
        Line2D([0], [0], marker="o", color=normal_color, linestyle="", markersize=11,
               label="Normal Node", markerfacecolor=normal_color),
        Line2D([0], [0], marker="o", color=redundant_color, linestyle="", markersize=9,
               label="Redundant Candidate", markerfacecolor=redundant_color),
        Line2D([0], [0], marker="x", color=removed_color, linestyle="", markersize=11,
               markeredgewidth=2.2, label="Removed Node"),
    ]
    fig.legend(handles=legend_elements, loc="lower center", ncol=5, fontsize=10, frameon=True, fancybox=True)
    plt.tight_layout()
    plt.subplots_adjust(bottom=0.10)
    plt.savefig(save_path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def plot_key_normal_nodes_only(
    G_original: nx.Graph,
    critical_labels: Dict,
    save_path: str,
    title: str = "Critical and Normal Nodes",
) -> None:
    plt.rcParams["font.sans-serif"] = ["Times New Roman"]
    plt.rcParams["axes.unicode_minus"] = False
    pos = get_positions(G_original)
    fig, ax = plt.subplots(figsize=(12, 12))
    fig.patch.set_facecolor("white")

    road_color = "#999999"
    critical_color = "#FFB700"
    normal_color = "#555555"
    critical_edge = "#C89200"

    for u, v in G_original.edges():
        if u in pos and v in pos:
            ax.plot(
                [pos[u][0], pos[v][0]],
                [pos[u][1], pos[v][1]],
                color=road_color,
                linewidth=0.8,
                alpha=0.75,
                zorder=1,
            )

    critical_pts = []
    normal_pts = []
    for nid in G_original.nodes():
        if nid not in pos:
            continue
        if critical_labels.get(nid, 0) == 1:
            critical_pts.append(pos[nid])
        else:
            normal_pts.append(pos[nid])

    if normal_pts:
        xs, ys = zip(*normal_pts)
        ax.scatter(xs, ys, c=normal_color, s=40, alpha=0.72, zorder=2, edgecolors="none")
    if critical_pts:
        xs, ys = zip(*critical_pts)
        ax.scatter(xs, ys, c=critical_color, s=36, alpha=1.0, zorder=5, edgecolors=critical_edge, linewidth=0.7)

    legend_elements = [
        Line2D([0], [0], color=road_color, lw=2.0, label="Road"),
        Line2D([0], [0], marker="o", color=critical_color, linestyle="", markersize=8,
               label="Critical Node", markerfacecolor=critical_color, markeredgecolor=critical_edge, markeredgewidth=0.7),
        Line2D([0], [0], marker="o", color=normal_color, linestyle="", markersize=11,
               label="Normal Node", markerfacecolor=normal_color),
    ]
    ax.legend(handles=legend_elements, loc="lower center", bbox_to_anchor=(0.5, -0.03), ncol=3, fontsize=10, frameon=True)
    ax.set_title(title, fontsize=15, fontweight="bold")
    ax.axis("off")
    ax.set_aspect("equal")
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def plot_ablation_bars(ablation_rows: Sequence[Dict], save_path: str, metric_keys: Sequence[str]) -> None:
    labels = [row["variant"] for row in ablation_rows]
    x = np.arange(len(labels))
    width = 0.14
    fig, ax = plt.subplots(figsize=(14, 7))
    colors = ["#1D3557", "#E63946", "#457B9D", "#2A9D8F", "#FFB703"]
    for i, metric in enumerate(metric_keys):
        vals = [row["metrics"][metric] for row in ablation_rows]
        ax.bar(x + (i - (len(metric_keys) - 1) / 2) * width, vals, width=width, label=metric.upper(), color=colors[i % len(colors)])
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=15)
    ax.set_ylabel("Score")
    ax.set_title("Ablation Study of Four-Branch Model", fontsize=15, fontweight="bold")
    ax.legend()
    ax.grid(True, axis="y", alpha=0.25)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_ablation_curves(curve_rows: Sequence[Dict], save_path: str, metric_keys: Sequence[str]) -> None:
    labels = [row["variant"] for row in curve_rows]
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    axes = axes.flatten()
    colors = ["#1D3557", "#E63946", "#457B9D", "#2A9D8F", "#FFB703", "#6A4C93", "#264653"]
    markers = ["o", "s", "^", "D", "P", "X", "v"]
    for ax, metric in zip(axes, metric_keys):
        for i, row in enumerate(curve_rows):
            points = row.get("curve", [])
            xs = [float(p["target_ndr"]) * 100.0 for p in points]
            ys = [float(p["metrics"][metric]) for p in points]
            ax.plot(
                xs,
                ys,
                marker=markers[i % len(markers)],
                color=colors[i % len(colors)],
                linewidth=2.0,
                markersize=6,
                label=labels[i],
            )
        ax.set_title(metric.upper(), fontsize=13, fontweight="bold")
        ax.set_xlabel("Target NDR (%)")
        ax.set_ylabel("Score")
        ax.grid(True, alpha=0.25)
    handles, legend_labels = axes[0].get_legend_handles_labels()
    if handles:
        fig.legend(handles, legend_labels, loc="lower center", ncol=min(4, len(legend_labels)), frameon=True)
    fig.suptitle("Multi-NDR Ablation Curves", fontsize=16, fontweight="bold")
    plt.tight_layout(rect=(0, 0.05, 1, 0.96))
    plt.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
